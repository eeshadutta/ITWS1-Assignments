#!/bin/bash
echo "Enter Monthly Income"
read mi
ai=`echo "scale=4;$mi*12" | bc`
c=`echo "$ai>300000" | bc`
if [ $c -eq 0 ]
then
	echo "NO TAX PAYMENT REQUIRED"
else
	echo -n "TAX PAYMENT REQUIRED:"
	awk "BEGIN {printf \"%.4f\n\", $ai*30/100}"
fi
