#!/bin/bash
count=1
cat $1 | sed '/^$/d'| while read line
do
  echo "$count) $line"
  count=`expr $count + 1`
done
