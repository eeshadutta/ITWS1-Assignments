#!/bin/bash
check=0
for i in `ls -1 | grep "txt"`
do
	n=`grep $1 $i | wc -l`
	if [[ $n -ne 0 ]]
	then 
		echo "$n lines in $i"
		check=1;
	fi
done
if [[ $check -eq 1 ]]
then
	exit 0
else
	exit 1
fi
