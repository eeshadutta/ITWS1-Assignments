#!/bin/bash
k=0
for i in `find -maxdepth 1 -mindepth 1 -type d`
do
	cd $i
	size=0
	for j in `find -type f -printf "%s\n"`
	do
		size=`expr $size + $j`
	done
	dir1[$k]=$i
	s[$k]=$size
	k=`expr $k + 1`
	cd ..
done
for ((i=0;i<$k;i++))
do
	n=`expr $i + 1`
	for ((j=$n;j<$k;j++))
	do
		if [[ ${s[$i]} -lt ${s[$j]} ]]
		then
			s=${s[$i]}
			s[$i]=${s[$j]}
			s[$j]=$s
			d=${dir1[$i]}
			dir1[$i]=${dir1[$j]}
                        dir1[$j]=$d
		fi
	done
done
for ((i=0;i<$k;i++))
do
	echo "${dir1[$i]} ${s[$i]}B"
done
echo

k=0
for i in `find -maxdepth 1 -mindepth 1 -type d`
do
        cd $i
        j=`find -type f | wc -l`
        dir2[$k]=$i
        nf[$k]=$j
        k=`expr $k + 1`
	cd ..
done
for ((i=0;i<$k;i++))
do
        n=`expr $i + 1`
        for ((j=$n;j<$k;j++))
        do
                if [[ ${nf[$i]} -lt ${nf[$j]} ]]
                then
                        f=${nf[$i]}
                        nf[$i]=${nf[$j]}
                        nf[$j]=$f
                        d=${dir2[$i]}
                        dir2[$i]=${dir2[$j]}
                        dir2[$j]=$d
                fi
        done
done
for ((i=0;i<$k;i++))
do
        echo "${dir2[$i]} ${nf[$i]}"
done

