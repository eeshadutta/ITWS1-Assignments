#!bin/bash
echo "Squares of numbers from 1 to 10:"
for ((i=1;i<=10;i++))
do
	square=`expr $i \* $i`
	echo $square
done

echo "Numbers n^n from 1 to 10:"
for ((i=1;i<=10;i++))
do
	n=$i
	for ((j=1;j<=i-1;j++))
	do
		n=`expr $n \* $i`
	done
	echo $n
done

echo "Odd Fibonacci numbers <=100:"
n1=0
n2=1
check=100
count=2
n=0
while [ $n -le $check ]
do
	n=`expr $n1 + $n2`
	n1=$n2
	n2=$n

	rem=`expr $n % 2`
	if [ $rem = 1 ]
	then
		echo $n
	fi
	count=`expr $count + 1`
done

