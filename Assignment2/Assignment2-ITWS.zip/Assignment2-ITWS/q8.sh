#!/bin/bash
for((i=1;i<=$#;i++))
do
if [ -f ${!i} ]
then
echo `ls -l ${!i}`
fi
done
