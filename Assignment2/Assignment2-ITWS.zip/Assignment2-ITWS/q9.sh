#!/bin/bash
echo "Enter your name"
read name
echo "Enter your birthdate"
read bdate
mdbdate=`echo $bdate | cut -d '-' -f 2,3`
ybdate=`echo $bdate | cut -d '-' -f 1`
mdtod=`date +%m-%d`
ytod=`date +%Y`

age=`expr $ytod - $ybdate`

if [ $mdbdate = $mdtod ]; then

	echo "Happy Birthday, $name. You are $age years old today!"
fi
