#!/bin/bash
cat to_replace.txt | xargs -n1 | xargs -I X mv ./replace/X.txt ./replace/XX.txt
