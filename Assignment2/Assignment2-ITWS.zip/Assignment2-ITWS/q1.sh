#!/bin/bash
warning=$1
critical=$2

k=1
for i in $(df -h | awk '{print $5}' | grep % | grep -v Use | cut -d "%" -f 1)
do        
	n=`df -h | awk '{print $1}' | grep -v Filesystem | head -n $k | tail -n1`

	if [ $i -lt $warning ]
	then
		echo "OK, $n, $i%"

	elif [ $i -ge $critical ]
	then
		echo "CRITICAL, $n, $i%"

	else
		echo "WARNING, $n, $i%"
	fi

	k=`expr $k + 1`
done
