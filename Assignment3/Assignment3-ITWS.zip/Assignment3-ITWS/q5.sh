#!/bin/bash

file1=$1
file2=$2

a="-k$3,$3"
for ((i=4;i<=$#;i++))
do
	a="$a -k${!i},${!i}"
done

paste -d "\n" $file1 $file2 | sort $a -n
