#!/bin/bash
makehtml()
{
echo "<!DOCTYPE html>"
echo "<html>"
echo "<title>Home Directory</title>" 
echo "<body>" 
echo "<table border="15" align ="center" cellpadding="10" bgcolor="4EE2EC">" 
ls -l ~/ | egrep '^d' | awk '{ for(i=9;i<=NF;i++){printf "%s \n", $i} }' | while read d
do
	echo "<tr>" 
	echo "<th colspan="3">$d</th>"
	echo "</tr>"
	echo "<tr>" 
	echo "<th>Name</th>" 
	echo "<th>Size</th>" 
	echo "<th>File/Dir</th>" 
	echo "</tr>" 
	ls -l ~/"$d" | awk '{for(i=9;i<=NF;i++){printf "%s ", $i};printf "\n"}' | sed '/^$/d' | while read f
do
	s=`du -sh ~/"$d"/"$f" | tr -s ' ' | cut -d ' ' -f 1 | cut -d '/' -f 1`
	echo "<tr>" 
	echo "<td>$f</td>" 
	echo "<td>$s</td>" 
	if [ ! -f "$f" ]
	then
		echo "<td>Dir</td>"
	else
		echo "<td>File</td>" 
	fi
	echo "</tr>" 
done
done
echo "</table>"
echo "</body>" 
} > q14.html
makehtml
firefox q14.html
