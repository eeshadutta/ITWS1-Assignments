#!/bin/bash
sed -i -e '/PIPE/d' ~/.bash_history 

n=`grep -c "|" ~/.bash_history`

for ((i=1;i<=$n;i++))
do
	echo PIPE >> ~/.bash_history 
done

cat ~/.bash_history | awk '{printf "%s\n", $1}' | sort | uniq -c | sort -r -k1,1 --numeric-sort | awk '{printf "%s  %s\n", $2, $1}'
