#!/bin/bash
read word
length=`echo $word | wc -c`
length=`expr $length - 1`
i=1
n=`expr $length / 2`
palindrome=0

while [[ $i -le $n ]]
do
	k=`echo $word | cut -c $i | tr '[:upper:]' '[:lower:]'`
	l=`echo $word | cut -c $length | tr '[:upper:]' '[:lower:]'`
	if [[ $k != $l ]]
	then
		palindrome=1
		break
	fi
	i=`expr $i + 1`
	length=`expr $length - 1`
done

if [[ $palindrome -eq 1 ]]
then
	echo "No"
else
	echo "Yes"
fi
