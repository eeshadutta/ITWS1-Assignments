#!/bin/bash
read oper
read n
#echo $oper

for ((i=0;i<$n;i++))
do
	read arr[$i]
done

if [[ $oper == '+' ]]
then
	sum=0
	for ((i=0;i<$n;i++))
	do
		sum=`echo "scale=4; $sum+${arr[$i]}" | bc`
	done
	awk "BEGIN {printf \"%.4f\n\", $sum}"
fi

if [[ $oper == '-' ]]
then    
        diff=${arr[0]}
        for ((i=1;i<$n;i++))
        do      
               diff=`echo "scale=4; $diff-${arr[$i]}" | bc`
        done    
        awk "BEGIN {printf \"%.4f\n\", $diff}"
fi      

if [[ $oper == '*' ]]
then
        product=1
        for ((i=0;i<$n;i++))
        do
                product=`echo "scale=4; $product*${arr[$i]}" | bc`
        done
        awk "BEGIN {printf \"%.4f\n\", $product}"
fi

if [[ $oper == '/' ]]
then
        quot=${arr[0]}
        for ((i=1;i<$n;i++))
        do
                quot=`echo "scale=4; $quot/${arr[$i]}" | bc`
        done
        awk "BEGIN {printf \"%.4f\n\", $quot}"
fi
