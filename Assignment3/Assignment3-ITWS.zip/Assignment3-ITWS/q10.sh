#!/bin/bash
n=$#
arr=("$@")

prod=1
for ((i=1;i<$n;i++))
do
	prod=$(($prod*${arr[$i]}))
done

res=1
for ((i=1;i<=$prod;i++))
do
	res=$(($res*$1))
done

echo $res
