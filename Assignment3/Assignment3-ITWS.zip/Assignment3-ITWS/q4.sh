#!/bin/bash

cat $1 | crontab &>/dev/null
if [[ $? -eq 0 ]]
then
	echo Yes
else
	echo No
fi
