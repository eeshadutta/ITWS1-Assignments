#!/bin/bash

elinks -dump $1 | tr '[:punct:]' ' ' | tr ' ' '\n' | xargs -n1 | tr -d '[:blank:]' | sort | uniq -i -c | sort -k1,1rn -k2,2 | awk '{print $2 " " $1}' > $3
elinks -dump $2 | tr '[:punct:]' ' ' | tr ' ' '\n' | xargs -n1 | tr -d '[:blank:]' | sort | uniq -i -c | sort -k1,1rn -k2,2 | awk '{print $2 " " $1}' >> $3

sort -nk2,2r -k1,1 $3 -o $3 
