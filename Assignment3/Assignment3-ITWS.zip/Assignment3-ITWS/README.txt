Q1) The script will print all the valid commands along with their arguments.

Q8 & Q9) Both questions are done as program.sh as specified in the assignment.

Q14) Submitted the script file q14.sh to generate q14.html as well as 14.html specific to the home directory of my computer.

Q15) Used command elinks to download the webpages. Script file q15.sh will accept two urls and a file as arguments. I have also submitted q15_url.txt and q15_ans.txt specific to two urls.
