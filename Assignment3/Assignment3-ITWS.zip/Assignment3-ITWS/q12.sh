#!/bin/bash
read date
date -d "$date" +'%d-%m-%Y'&>/dev/null
if [[ $? -eq 0 ]]
then
	date -d "$date" +'%m/%d/%Y'
	date -d "$date" +'%d-%m-%Y'
else 
	echo "Invalid"
fi
