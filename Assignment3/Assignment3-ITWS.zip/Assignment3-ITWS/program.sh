#!/bin/bash
oper=$1

if [[ $1 == 'write' ]]
then
	eno=$2
	ename=$3
	salary=$4
	echo "$eno,$ename,$salary" >> employee.txt
	echo "Done"
fi

if [[ $1 == 'read' ]]
then
	if [[ $2 == 'eno' ]]
	then
		grep "$3," employee.txt
	elif [[ $2 == 'name' ]]
	then
		grep -w "$3" employee.txt
	elif [[ $2 == 'salary' ]]
	then
		grep -w "$3" employee.txt
	fi
fi

if [[ $1 == 'update' ]]
then
	r=`grep -w "$2" employee.txt`
	sed -i "s/$r/$2,$3,$4/g" ./employee.txt
	echo "Done"
fi

if [[ $1 == 'delete' ]]
then 
	eno=$2
	sed -i "/$eno/d" ./employee.txt
	echo "Done"
fi

if [[ $1 == 'duplicate' ]]
then
	sort employee.txt | uniq -d	
fi

if [[ $1 == 'nthsalary' ]]
then
	n=`cat employee.txt | cut -d ',' -f3 | sort -r --numeric-sort | uniq | head -n$2 | tail -n1`
	grep -w "$n" employee.txt
fi
