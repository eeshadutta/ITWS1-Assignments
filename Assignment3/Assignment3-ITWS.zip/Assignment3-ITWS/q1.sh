#!/bin/bash

read word
flag=0
permute()
{
	if [ "${#1}" = 1 ]; then
		echo "${2}${1}"
	else
		for i in $(seq 0 $((${#1}-1)) )
		do
			pre="${2}${1:$i:1}"
			part1="${1:0:$i}"
			part2="${1:$((i+1))}"
			part="${part1}${part2}"
			permute "$part" "$pre"
		done
	fi
}

permute $word | while read word
do
	command -v $word &>/dev/null
	if [[ $? -eq 0 ]]
	then
		echo Yes
		echo $word
		echo "Arguments=>"
		$word --help | sed -n "/-[a-z]/p"
		flag=0
	else
		flag=1
	fi
done

if [[ $flag -eq 1 ]]
  then
    echo No
fi
