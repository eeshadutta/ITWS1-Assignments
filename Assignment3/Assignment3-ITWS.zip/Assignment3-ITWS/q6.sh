#!/bin/bash
read string
x=`echo -n $string | tr -d ")" | tr -d "(" | tr -s ' '`
echo "==>($x)" | sed 's/\B/ /g' 
